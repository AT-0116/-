package com.demo.service;

import com.demo.vo.Inout;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

/**
 * Inout模块的Service层（业务层）接口，提供业务方法的抽象
 */
public interface InoutService {
    /**
     * 增加出入院
     *
     * @param vo
     * @return
     */
    boolean insert(Inout vo);

    /**
     * 删除出入院
     *
     * @param ids
     * @return
     */
    boolean delete(Collection<Serializable> ids);

    /**
     * 修改出入院
     *
     * @param vo
     * @return
     */
    boolean update(Inout vo);

    /**
     * 根据主键Id查询出入院详情
     *
     * @param id
     * @return
     */
    Inout get(Serializable id);

    /**
     * 根据条件查询出入院的列表与数量
     *
     * @param params
     * @return
     */
    Map<String, Object> list(Map<String, Object> params);
}
