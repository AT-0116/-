package com.demo.service;

import com.demo.vo.Room;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

/**
 * Room模块的Service层（业务层）接口，提供业务方法的抽象
 */
public interface RoomService {
    /**
     * 增加房间
     *
     * @param vo
     * @return
     */
    boolean insert(Room vo);

    /**
     * 删除房间
     *
     * @param ids
     * @return
     */
    boolean delete(Collection<Serializable> ids);

    /**
     * 修改房间
     *
     * @param vo
     * @return
     */
    boolean update(Room vo);

    /**
     * 根据主键Id查询房间详情
     *
     * @param id
     * @return
     */
    Room get(Serializable id);

    /**
     * 根据条件查询房间的列表与数量
     *
     * @param params
     * @return
     */
    Map<String, Object> list(Map<String, Object> params);
}
