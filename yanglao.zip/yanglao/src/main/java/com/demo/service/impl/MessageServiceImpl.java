package com.demo.service.impl;

import com.demo.dao.MessageMapper;
import com.demo.service.MessageService;
import com.demo.vo.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Message模块的Service层（业务层）的具体实现类，对MessageService接口中定义的抽象方法作出具体的功能实现
 */
@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageMapper messageMapper;


    //@Override
    public boolean insert(Message vo) {
        return this.messageMapper.doCreate(vo) == 1;
    }

    //@Override
    public boolean delete(Collection<Serializable> ids) {
        return ids.isEmpty() ? false : this.messageMapper.doRemoveBatch(ids) == ids.size();
    }

    //@Override
    public boolean update(Message vo) {
        return this.messageMapper.doUpdate(vo) == 1;
    }

    //@Override
    public Message get(Serializable id) {
        return this.messageMapper.findById(id);
    }

    //@Override
    public Map<String, Object> list(Map<String, Object> params) {
        Map<String, Object> resultMap = new HashMap();
        resultMap.put("totalCount", this.messageMapper.getAllCount(params));
        resultMap.put("list", this.messageMapper.findAllSplit(params));
        return resultMap;
    }
}
