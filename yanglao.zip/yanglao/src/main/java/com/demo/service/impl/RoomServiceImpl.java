package com.demo.service.impl;

import com.demo.dao.RoomMapper;
import com.demo.service.RoomService;
import com.demo.vo.Room;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Room模块的Service层（业务层）的具体实现类，对RoomService接口中定义的抽象方法作出具体的功能实现
 */
@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomMapper roomMapper;


    //@Override
    public boolean insert(Room vo) {
        return this.roomMapper.doCreate(vo) == 1;
    }

    //@Override
    public boolean delete(Collection<Serializable> ids) {
        return ids.isEmpty() ? false : this.roomMapper.doRemoveBatch(ids) == ids.size();
    }

    //@Override
    public boolean update(Room vo) {
        return this.roomMapper.doUpdate(vo) == 1;
    }

    //@Override
    public Room get(Serializable id) {
        return this.roomMapper.findById(id);
    }

    //@Override
    public Map<String, Object> list(Map<String, Object> params) {
        Map<String, Object> resultMap = new HashMap();
        resultMap.put("totalCount", this.roomMapper.getAllCount(params));
        resultMap.put("list", this.roomMapper.findAllSplit(params));
        return resultMap;
    }
}
