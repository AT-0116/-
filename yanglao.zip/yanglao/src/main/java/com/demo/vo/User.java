package com.demo.vo;

import java.io.Serializable;

/**
 * 用户（t_user表对应的Java实体类）
 */
public class User implements Serializable {
    private Long id;//主键
    private String username;//用户名
    private String password;//密码
    private String realName;//姓名
    private String userType;//类型:管理员/普通用户
    private Long createBy;//创建人

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}
