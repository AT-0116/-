package com.demo.vo;

import java.io.Serializable;

/**
 * 出入院（t_inout表对应的Java实体类）
 */
public class Inout implements Serializable {
    private Long id;//主键
    private String inoutName;//姓名
    private String inoutJingrushijian;//进入时间
    private String inoutLikaishijian;//离开时间
    private String inoutZhuangtai;//状态:在住/离开
    private String inoutText;//备注
    private Long createBy;//创建人

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getInoutName() {
        return inoutName;
    }

    public void setInoutName(String inoutName) {
        this.inoutName = inoutName;
    }
    public String getInoutJingrushijian() {
        return inoutJingrushijian;
    }

    public void setInoutJingrushijian(String inoutJingrushijian) {
        this.inoutJingrushijian = inoutJingrushijian;
    }
    public String getInoutLikaishijian() {
        return inoutLikaishijian;
    }

    public void setInoutLikaishijian(String inoutLikaishijian) {
        this.inoutLikaishijian = inoutLikaishijian;
    }
    public String getInoutZhuangtai() {
        return inoutZhuangtai;
    }

    public void setInoutZhuangtai(String inoutZhuangtai) {
        this.inoutZhuangtai = inoutZhuangtai;
    }
    public String getInoutText() {
        return inoutText;
    }

    public void setInoutText(String inoutText) {
        this.inoutText = inoutText;
    }
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}
