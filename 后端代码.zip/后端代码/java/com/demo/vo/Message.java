package com.demo.vo;

import java.io.Serializable;

/**
 * 信息（t_message表对应的Java实体类）
 */
public class Message implements Serializable {
    private Long id;//主键
    private String messageName;//名字
    private String messageSex;//性别:男/女
    private String messageIdno;//身份证号
    private String messageTel;//手机号
    private String messageBir;//出生日期
    private String messageZhuzhi;//家庭住址
    private String messageText;//备注
    private Long createBy;//创建人

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getMessageName() {
        return messageName;
    }

    public void setMessageName(String messageName) {
        this.messageName = messageName;
    }
    public String getMessageSex() {
        return messageSex;
    }

    public void setMessageSex(String messageSex) {
        this.messageSex = messageSex;
    }
    public String getMessageIdno() {
        return messageIdno;
    }

    public void setMessageIdno(String messageIdno) {
        this.messageIdno = messageIdno;
    }
    public String getMessageTel() {
        return messageTel;
    }

    public void setMessageTel(String messageTel) {
        this.messageTel = messageTel;
    }
    public String getMessageBir() {
        return messageBir;
    }

    public void setMessageBir(String messageBir) {
        this.messageBir = messageBir;
    }
    public String getMessageZhuzhi() {
        return messageZhuzhi;
    }

    public void setMessageZhuzhi(String messageZhuzhi) {
        this.messageZhuzhi = messageZhuzhi;
    }
    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}
