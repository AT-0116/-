package com.demo.vo;

import java.io.Serializable;

/**
 * 房间（t_room表对应的Java实体类）
 */
public class Room implements Serializable {
    private Long id;//主键
    private String roomLouhao;//楼号
    private String roomRoomhao;//房间号
    private String roomLeixin;//类型:单间/标间
    private String roomPrice;//价格
    private String roomName;//入住人
    private String roomText;//备注
    private Long createBy;//创建人

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getRoomLouhao() {
        return roomLouhao;
    }

    public void setRoomLouhao(String roomLouhao) {
        this.roomLouhao = roomLouhao;
    }
    public String getRoomRoomhao() {
        return roomRoomhao;
    }

    public void setRoomRoomhao(String roomRoomhao) {
        this.roomRoomhao = roomRoomhao;
    }
    public String getRoomLeixin() {
        return roomLeixin;
    }

    public void setRoomLeixin(String roomLeixin) {
        this.roomLeixin = roomLeixin;
    }
    public String getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(String roomPrice) {
        this.roomPrice = roomPrice;
    }
    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }
    public String getRoomText() {
        return roomText;
    }

    public void setRoomText(String roomText) {
        this.roomText = roomText;
    }
    public Long getCreateBy() {
        return createBy;
    }

    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }
}
